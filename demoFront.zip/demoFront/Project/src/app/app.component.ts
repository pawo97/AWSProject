import { Component, OnInit } from '@angular/core';
import { AwsService } from './services/aws.service';


class Image {
  name: string;
  id: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'Project';
  imageList: Array<Image>;

  constructor(private awsService: AwsService){

  }
  //name = "test1.txt";
  onclickButton(name: string){
    this.awsService.download(name).subscribe();
  }

  ngOnInit(){
    this.awsService.getFiles().subscribe(result => this.imageList = result);
  }
}
